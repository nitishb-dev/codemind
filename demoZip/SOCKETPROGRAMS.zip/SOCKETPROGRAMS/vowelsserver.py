import socket
s = socket.socket()
s.bind(('localhost', 12345))
s.listen(5)
while True:
   c,addr = s.accept()
   word = c.recv(1024).decode()
   print(word)
   Vow = ['A', 'E', 'I', 'O', 'U', 'a', 'e', 'i', 'o', 'u']
   Vow_count = 0
   for i in word:
      if i in Vow:
         Vow_count+=1
         msg1 = len(word)
         c.send(("Length of updated name is" + str(msg1)+"\nThe number of vowels in given name  is "+str(Vow_count)).encode())
c.close()