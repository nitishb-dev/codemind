import socket
s=socket.socket()
s.bind(('localhost',1235))
s.listen(5)
user_creds = {"Nitish":"nr123","Ryder":"1234 "}
while True : 
   c,addr = s.accept()
   user_pw = c.recv(1024).decode()
   user_id,pw = user_pw.split("_._sep_._")
   if (user_id not in user_creds):
      c.send("ACCOUNT NOT FOUND".encode())
   else: 
       if( user_creds [ user_id ] != pw): 
          c.send("Incorect Password".encode())
       elif (user_creds[user_id] == pw):		
           c.send("Login Successful".encode())
   c.close()
