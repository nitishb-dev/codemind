import socket 
s = socket.socket()
s.bind(('192.168.1.5', 10888))
s.listen(5)
while True:
   c, addr = s.accept() 
   msg = c.recv(1024) 
   encMsg = '' 
for i in msg: 
   encMsg += chr(ord(i)+1)
c.send(encMsg)
