import socket
loc_addr = ("localhost", 8888)
ss = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
ss.bind(loc_addr)
while True:
   msg, addr = ss.recvfrom(1024)
   print(msg)
   rev_msg = ""
   for i in range(len(msg)):
      rev_msg += msg[(len(msg)-i)-1]
      ss.sendto(rev_msg, addr)