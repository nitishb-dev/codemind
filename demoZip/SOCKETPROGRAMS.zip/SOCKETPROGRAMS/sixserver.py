import socket

s=socket.socket()
s.bind(('192.168.1.5',8881))
s.listen(5)

while True:
   c,addr = s.accept()
   s_num=c.recv(1024)
   tot=(int(s_num[0])+int(s_num[2])+int(s_num[4]))
   c.send(bytes(tot))
   c.close()