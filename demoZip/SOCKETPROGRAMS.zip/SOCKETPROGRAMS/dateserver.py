from datetime import date
import socket

s=socket.socket()
s.bind(('192.168.1.5', 56540))
s.listen(5)

today=date.today()
time=today.strftime("%d/%m/%Y")

while True:
    c,addr=s.accept()
    c.send(time.encode())
    c.close()