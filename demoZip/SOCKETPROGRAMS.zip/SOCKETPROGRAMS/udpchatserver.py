import socket
addr = ('localhost', 12345)
ss = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
ss.bind(addr)
while True:
   msg, addr1 = ss.recvfrom(1024)
   print("Client: "+ msg.decode())
   if msg.decode() == "BYE":
      print("Chat Ended...")
      break
   msg = input("You: ")
   ss.sendto(msg.encode(),addr1)
   if msg == "BYE":
      print("Chat Ended...")
      break