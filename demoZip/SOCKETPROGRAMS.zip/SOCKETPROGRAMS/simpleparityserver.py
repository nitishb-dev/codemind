import socket 
s = socket.socket() 
s.bind(("localhost", 8888)) 
s.listen(5) 
while True: 
   c, addr = s.accept()  
   dw = c.recv(1024)    
   count, parity_bit = 0, "0"  
   for i in dw:  
      count += 1 if i=="1" else 0  
   if count%2 == 1:   
      parity_bit = "1" 
   c.send("Code Word is: "+dw+parity_bit) 
