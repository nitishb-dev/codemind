import socket
s=socket.socket()
s.connect(('192.168.1.5',8881))
s.send(bytes(input("Enter 6 digit number:")))
print(s.recv(1024))
s.close()