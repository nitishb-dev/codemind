import socket
addr = ("localhost", 8888)
cs = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
cs.sendto(raw_input("Enter Date of Birth (dd-mm-yyyy): "), addr)
print(cs.recvfrom(1024)[0])
