import socket
addr = addr = ('localhost', 12345)
cs = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
while True:
   msg = input("You: ")
   cs.sendto(msg.encode(), addr)
   if msg == "BYE":
       print("Chat Ended...")
       break
   msg = cs.recvfrom(1024)[0].decode()
   print("Server: "+msg)
   if msg == "BYE":
      print("Chat Ended...")
      break