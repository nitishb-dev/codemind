import socket
s = socket.socket()
s.connect(('localhost', 12345))
msg1, msg2 = input("Enter First Name: "), input("Enter Last Name: ")
s.send((msg1+msg2).encode())
print(s.recv(1024).decode())
s.close()