import socket
s=socket.socket()
s.connect(('localhost',1235))
user_id = input ("Enter User ID : ")
pw = input("Enter Password : ")
s.send((user_id+"_._sep_._"+pw).encode())
print(s.recv(1024).decode())
s.close()