import socket 
s=socket.socket()
host=socket.gethostname()
port=12345
s.bind(('192.168.1.4',56725))
s.listen(5)
while True:
	c,addr=s.accept()
	print("Got connection",addr)
	print("Thank you for connection")
	c.close()