import socket
s=socket.socket()
s.connect(('192.168.1.5', 10888))
s.send(bytes('Enter input: ',encoding='utf-8')) 
print("ENCODED STRING: "+s.recv(1024))
