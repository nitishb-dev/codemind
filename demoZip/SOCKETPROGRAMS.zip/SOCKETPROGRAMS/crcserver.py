import socket
import os
s = socket.socket()
host = '127.0.0.2'
port = 12347
s.bind((host, port))
s.listen(5)
while True:
   c, addr = s.accept()
   print ('Got connected from', addr)
   c.send('Thank you for connecting'.encode())
   div = c.recv(1024).decode()
   number = c.recv(1024).decode()
   numlen = len(number)
   divlen = len(div)
   number = list(number)
   newcode = []
   diff = numlen - divlen
   newdiff = diff - 1
   for i in range(newdiff, numlen):
      newcode.append(number[i])
   if(number[-5] == '0'):
      number[-5] = '1'
   else:
      number[-5] = '0'
   if(number[-9] == '0'):
      number[-9] = '1'
   else:
      number[-9] = '0'
   for i in range(0, divlen):
      number.pop
   num = ''.join(number)
   code = ''.join(newcode)
   def crc(number, div, code):
      msg = ""
      msg = msg + code
      div = list(div)
      for i in range(len(msg)-len(code)):
         if msg[i] == '1':
            for j in range(len(div)):
               msg[i+j] = str((int(msg[i+j])+int(div[j]))%2)
      return ''.join(msg[-len(code):])
code = crc(num, div, code)
check = '0'
newdivlen = divlen - 1
for i in range(0, newdivlen):
   check = check + '0'
if(code == check):
   print('Error not detected')
else:
   print('Error detected')
c.close()