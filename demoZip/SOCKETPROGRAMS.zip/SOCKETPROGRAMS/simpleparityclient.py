import socket 
s = socket.socket() 
s.connect(("localhost", 8888)) 
s.send(raw_input("Enter DataWord: ")) 
print(s.recv(1024)) 
