import socket
from datetime import date
loc_addr = ("localhost", 8888)
ss = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
ss.bind(loc_addr)
curr_date = date.today().strftime("%d-%m-%Y")
yr = int(curr_date[-4:])
mon = int(curr_date[3:5])
day = int(curr_date[0:2])
print("Current Date ",yr,mon,day)
while True:
   dob, addr = ss.recvfrom(1024)
   years = int(dob[-4:])
   months = int(dob[3:5])
   days = int(dob[0:2])
   diff = (date(yr,mon,day) - date(years, months, days)).days
   n_yrs = diff//365
   diff %= 365
   n_months = diff//30
   diff %= 30
   n_days = diff
   res = "Your Age is: "+str(n_yrs)+" years, "+str(n_months)+" months, "+str(n_days)+" days"
   ss.sendto(res, addr)
