import socket
addr = ("localhost", 8888)
cs = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
cs.sendto(input("Name: ",), addr)
print("Reversed String: ", cs.recvfrom(1024))
