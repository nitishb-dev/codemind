import socket
s = socket.socket()
host = '127.0.0.2'
port = 12347
div = str(input("Enter the divisor."))
number = "1100000110000000"
s.connect((host, port))
s.send(div.encode())
print(s.recv(1024).decode())
def crc(msg, div, code='000'):
   msg = msg + code
   msg = list(msg)
   div = list(div)
   for i in range(len(msg)-len(code)):
      if msg[i] == '1':
         for j in range(len(div)):
            msg[i+j] = str((int(msg[i+j])+int(div[j]))%2)
   return ''.join(msg[-len(code):])
code = crc(number, div)
number = number + code
print('The codeword is: ', number)
s.send(number.encode())
s.close()