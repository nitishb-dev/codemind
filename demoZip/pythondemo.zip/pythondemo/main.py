# from fastapi import FastAPI, Depends, HTTPException
# from pydantic import BaseModel
# from db.session import get_db
# from llm.agent import process_question

# app = FastAPI(title="ANARIX AI-AGENT")

# class QuestionRequest(BaseModel):
#     question: str

# @app.post("/ask")
# async def ask_question(request: QuestionRequest, db=Depends(get_db)):
#     try:
#         return process_question(request.question, db)
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))
# @app.get("/")
# def read_root():
#     return {"message": "ANARIX AI Agent is running! Visit /docs for API UI"}


from fastapi import FastAPI, Depends, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from db.session import get_db
from llm.agent import process_question
import os

app = FastAPI(
    title="ANARIX AI-AGENT",
    description="Intelligent E-commerce Data Assistant",
    version="1.0.0"
)

# CORS middleware to allow frontend connections
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static files (charts/screenshots)
if os.path.exists("assets"):
    app.mount("/assets", StaticFiles(directory="assets"), name="assets")

class QuestionRequest(BaseModel):
    question: str

class QuestionResponse(BaseModel):
    question: str
    sql_generated: str = None
    query_result: list = None
    answer: str
    chart_path: str = None
    type: str

@app.post("/ask", response_model=QuestionResponse)
async def ask_question(request: QuestionRequest, db=Depends(get_db)):
    """
    Process a natural language question and return SQL query, results, and chart if applicable.
    """
    try:
        if not request.question or request.question.strip() == "":
            raise HTTPException(status_code=400, detail="Question cannot be empty")
        
        result = process_question(request.question, db)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing question: {str(e)}")

@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "message": "ANARIX AI Agent is running!"}

@app.get("/")
def read_root():
    return {
        "message": "ANARIX AI Agent is running!", 
        "docs": "/docs",
        "health": "/health",
        "ask": "/ask"
    }